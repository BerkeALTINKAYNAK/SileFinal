package com.example.belediye.takip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelediyeTakipApplication {
    public static void main(String[] args) {
        SpringApplication.run(BelediyeTakipApplication.class, args);
    }
}
